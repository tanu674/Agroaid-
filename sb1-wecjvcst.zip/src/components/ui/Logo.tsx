import React from 'react';

interface LogoProps {
  variant?: 'light' | 'dark';
  size?: 'sm' | 'md' | 'lg';
}

const Logo: React.FC<LogoProps> = ({ variant = 'dark', size = 'md' }) => {
  const sizes = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-10 h-10',
  };

  const primaryColor = variant === 'light' ? '#ffffff' : '#3c9447';
  const secondaryColor = variant === 'light' ? '#3c9447' : '#ffffff';

  return (
    <svg 
      className={sizes[size]} 
      viewBox="0 0 48 48" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <rect width="48" height="48" rx="8" fill={primaryColor} />
      <path d="M24 12C22.8954 12 22 12.8954 22 14V22.9432C19.3859 23.4407 17 25.5303 17 28C17 30.4697 19.3859 32.5593 22 33.0568V34C22 35.1046 22.8954 36 24 36C25.1046 36 26 35.1046 26 34V33.0568C28.6141 32.5593 31 30.4697 31 28C31 25.5303 28.6141 23.4407 26 22.9432V14C26 12.8954 25.1046 12 24 12Z" fill={secondaryColor} />
      <path d="M24 31C25.6569 31 27 29.6569 27 28C27 26.3431 25.6569 25 24 25C22.3431 25 21 26.3431 21 28C21 29.6569 22.3431 31 24 31Z" fill={primaryColor} />
    </svg>
  );
};

export default Logo;